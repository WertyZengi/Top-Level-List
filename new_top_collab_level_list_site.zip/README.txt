Top Collab Level list — новый сайт

Файлы:
- index.html — страница сайта
- grief-easy.jpg — картинка первого места
- kocmoc-remake.jpg — картинка второго места

Для публикации на GitHub Pages загрузите все три файла в корень нового репозитория.
